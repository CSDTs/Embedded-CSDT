#ifndef strain_gauge_h_
#define strain_gauge_h_

#include <cmath>
#include <vector>
#include <iostream>

using namespace std;

class strain_gauge{
public:
	strain_gauge():sg_factor(0){};

	strain_gauge(float sg_factor_temp):sg_factor(sg_factor_temp){};

	float get_sg_factor(){return sg_factor;}

	float get_resistance(){return r_original;}

	

protected:
	float sg_factor;
	int r_original;
};

vector<float> obtain_polymals(){
	cout << "Enter the polynomial number of equation: " << endl;
	int length;
	cin >> length;
	vector<float> poly_num(length+1);

	for (int i=poly_num.size()-1;i>=0;i--){
		cout << "Please enter coefficients for the voltage's " << i << "th exponential." << endl;
		float temp;
		cin >> temp;
		poly_num[i] = temp;
	}
	cout << "Equation set for force calculation, to reset it, please enter 1, to continue please enter 2." << endl;
	int command;
	cin >> command;
	if (command == 1){
		poly_num = obtain_polymals();
	}
	
	return poly_num;
	
}

float obtain_force(vector<float> poly_num){
	cout << "To measure force, please enter the output voltage of circuit:" << endl;

	int out_vol;
	cin >> out_vol;
	float force=0;

	for (int i=0;i<poly_num.size();i++){
		float change;
		change = poly_num[i]* pow(out_vol,i);
		force += change;
	}
	return force;
}


#endif