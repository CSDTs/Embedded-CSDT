#include "strain_gauge.h"
#include <cmath>
#include <vector>
#include <iostream>

using namespace std;


int main(){
	
	vector<float> poly_func = obtain_polymals();
	float force = obtain_force(poly_func); 

	cout<< "\n ***The force this hair can handle before breaking is: " << force << " Newton.***" << endl; 
	cout <<"\nFor the next step:" << endl;

	cout <<"\nTo keep using the same testing system, please enter 1.\nTo reset the system, please press 2, to exit, please enter any other number." << endl;

	bool decide = true;
	while (decide==true){
		
		int input;
		cin >> input;
		if (input == 2){
			vector<float> poly_func = obtain_polymals();
			force = obtain_force(poly_func);
			cout<< "\n***The force this hair can handle before breaking is: " << force << " Newton.***" << endl; 
			cout <<"\nFor the next step:" << endl;
			cout <<"\nTo keep using the same testing system, please enter 1\nTo reset the system, please press 2, to exit, please enter any other number." << endl;

		}
		else if (input == 1){
			force = obtain_force(poly_func);
			cout<< "\n***The force this hair can handle before breaking is: " << force << " Newton.***" << endl; 
			cout <<"\nFor the next step:" << endl;
			cout <<"\nTo keep using the same testing system, please enter 1\nTo reset the system, please press 2, to exit, please enter any other number." << endl;
		}

		else if (input != 1 && input != 2){
			cout << "Thank you for using C-Stem hair force measuring system." << endl;
			break;
		}	
	}
	return 0;
}