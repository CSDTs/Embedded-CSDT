%Data for untreated & treated hair obtained from testing
force=[0,0.25,0.5,0.75,1,1.25,1.5,1.6]';
voltage=[2.79723,2.78178,2.75993,2.70889,2.62578,2.54302,2.48983,2.45532]';

%Plot both graphs in one
figure(1)
subplot(2,1,1)
plot(voltage,force,'ro');
xlim([min(voltage)*0.98,max(voltage)*1.02]); %Make the data points away from the edge of graph
ylim([min(force-.2)*0.9,max(force)*1.1]);
xlabel('Voltage');
ylabel('Force');
title('Data points retrieved from testing')
subplot(2,1,2)
plot(voltage,force,'ro');
hold on
%Obtain curve based on data points
f=fit(voltage,force,'poly2')
plot(f,'b-');
xlim([min(voltage)*0.98,max(voltage)*1.02]);
ylim([min(force-.2)*0.9,max(force)*1.1]);
title('Fit the data into a line')
hold off
xlabel('Voltage');
ylabel('Force');