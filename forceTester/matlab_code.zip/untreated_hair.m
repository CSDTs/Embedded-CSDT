%Data for untreated & treated hair obtained from testing
untreated = [0.7,1.25,.85,.4,1.3,1.1,1.1,1.75,1.05,.4,1.5,1.15,.9,.75,1.3,1.2];
treated = [.5 .8 .55 .6 .7 .45 .6 .95 .65 .75 .7 .5 .6 .25 .6 .55]';

%Untreated data distribution graph
figure(1)
h1=histfit(untreated,5);
set(h1(1),'facecolor','[0.5843 0.8157 0.9882]');set(h1(2),'color','r');
grid on
xlabel('Force');ylabel('Number');title('Distribution before treatment');

%Treated data distribution graph
figure(2)
h2=histfit(treated,5);
set(h2(1),'facecolor','[0.5843 0.8157 0.9882]');set(h2(2),'color','r');
grid on
xlabel('Force');ylabel('Number');title('Distribution after treatment');

%Comparison graph
figure(3)
h3=histfit(untreated,5);
hold on
h4=histfit(treated,5);
delete(h3(1));
set(h3(2),'color','g');
delete(h4(1));
set(h4(2),'color','m');
hold off
legend('Before treat','After treat');
grid on
xlabel('Force');ylabel('Number');title('Distribution Comparison');
